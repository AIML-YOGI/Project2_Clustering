1) project2_Q1to10.ipynb : please execute for questions 1 through 10
2) Project2_Q11 12 SVD.ipynb : please execute for questions 11 and 12 for SVD for 20 classes
3) Project2_Q11 12 NMF.ipynb : please execute for questions 11 and 12 for NMF for 20 classes